from django.urls import path

from .views import (
    RegisterView,
    RegisterVerifyCodeView,
    LoginView,
    SendOTPView,
    OTPLoginView,
    ProfileView,
    RefreshTokenView,
    MyShopsView,
    MyShopHistoryView,
    MeView,
)

urlpatterns = [
    path("register/", RegisterView.as_view()),
    path("verify_register/", RegisterVerifyCodeView.as_view()),
    path("login/", LoginView.as_view()),
    path("send_otp/", SendOTPView.as_view()),
    path("login_otp/", OTPLoginView.as_view()),
    path("profile/", ProfileView.as_view()),
    path("refresh/", RefreshTokenView.as_view()),
    path('my_shops/', MyShopsView.as_view()),
    path('my_shops/<int:shop_id>/history/', MyShopHistoryView.as_view()),
    path('me/', MeView.as_view()),
]