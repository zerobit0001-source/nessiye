from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.tokens import RefreshToken as JWTRefreshToken
from rest_framework.permissions import IsAuthenticated
import random
from utils import send_otp_code
from customer_management.models import CustomerShop
from sales.models import Sale
from sales.serializers import SaleSerializer
from debts.models import Debt
from debts.serializers import DebtSerializer
from django.db.models import Sum, Count
from .models import User, OtpCode
from .serializers import (
    RegisterSerializer,
    RegisterVerifyCodeSerializer,
    LoginSerializer,
    SendOTPSerializer,
    OTPLoginSerializer,
)


class RefreshTokenView(APIView):
    """This view allows clients to refresh their access token using a valid refresh token."""
    def post(self, request):
        refresh_token = request.data.get("refresh")

        if not refresh_token:
            return Response(
                {"ok": False, "error": "توکن ارسال نشده است"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            refresh = JWTRefreshToken(refresh_token)
            return Response({
                "ok": True,
                "access": str(refresh.access_token)
            })
        except Exception:
            return Response(
                {"ok": False, "error": "توکن نامعتبر یا منقضی شده است"},
                status=status.HTTP_400_BAD_REQUEST
            )




class RegisterView(APIView):
    """This view handles user registration by
    accepting phone number, full name, password, and optional shop details.
    It generates an OTP code for verification and creates a temporary OtpCode entry."""
    def post(self, request):

        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        phone_number = serializer.validated_data["phone_number"]

        if User.objects.filter(phone_number=phone_number).exists():
            return Response(
                {   "ok": False,
                    "error": "این شماره قبلاً ثبت شده است"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        if serializer.is_valid():
            random_code = random.randint(100000, 999999)
            # send_otp_code(phone_number, random_code)
            OtpCode.objects.create(
                phone_number=phone_number,
                code=random_code,
                full_name=serializer.validated_data["full_name"],
                password=serializer.validated_data["password"],
                is_shop=serializer.validated_data["is_shop"],
                shop_name=serializer.validated_data.get("shop_name", ""),
                shop_address=serializer.validated_data.get("shop_address", "")
            )
        
            return Response({
                "ok": True,
                "message": "کد تایید به شماره شما ارسال شد"
            })
    
class RegisterVerifyCodeView(APIView):
    """This view verifies the OTP code sent to the user's phone number during registration."""
    def post(self, request):

        serializer = RegisterVerifyCodeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        phone_number = serializer.validated_data["phone_number"]
        code = serializer.validated_data["code"]

        try:
            otp_code = OtpCode.objects.filter(
                phone_number=phone_number,
                code=code
            ).order_by("-created_at").first()
        except OtpCode.DoesNotExist:
            return Response(
                {
                    "ok": False,
                    "error": "کد تایید اشتباه است"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        if not otp_code.is_valid():
            return Response(
                {
                    "ok": False,
                    "error": "کد تایید منقضی شده است"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        user = User.objects.create_user(
            phone_number=phone_number,
            full_name=otp_code.full_name,
            password=otp_code.password,
            is_shop=otp_code.is_shop,
            shop_name=otp_code.shop_name,
            shop_address=otp_code.shop_address
        )

        otp_code.delete()

        refresh = RefreshToken.for_user(user)

        return Response({
            "ok": True,
            "message": "ثبت نام موفق",
            "refresh": str(refresh),
            "access": str(refresh.access_token)
        })


class LoginView(APIView):

    def post(self, request):

        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        phone_number = serializer.validated_data["phone_number"]
        password = serializer.validated_data["password"]

        user = authenticate(
            request,
            phone_number=phone_number,
            password=password
        )

        if user is None:
            return Response(
                {
                    "ok": False,
                    "error": "شماره یا رمز عبور اشتباه است"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        refresh = RefreshToken.for_user(user)

        return Response({
            "ok": True,
            "message": "ورود موفق",
            "refresh": str(refresh),
            "access": str(refresh.access_token)
        })
    

class SendOTPView(APIView):

    def post(self, request):
        serializer = SendOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        phone_number = serializer.validated_data["phone_number"]

        if not User.objects.filter(phone_number=phone_number).exists():
            return Response(
                {
                    "ok": False,
                    "error": "کاربر یافت نشد"
                 },
                status=status.HTTP_404_NOT_FOUND
            )

        code = random.randint(100000, 999999)

        OtpCode.objects.create(
            phone_number=phone_number,
            code=str(code)
        )

        # send_otp_code(phone_number, code)

        return Response(
            {
                "ok": True,
                "message": "کد تایید ارسال شد"
             },
            status=status.HTTP_200_OK
        )


class OTPLoginView(APIView):

    def post(self, request):
        serializer = OTPLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        phone_number = serializer.validated_data["phone_number"]
        code = serializer.validated_data["code"]

        if not User.objects.filter(phone_number=phone_number).exists():
            return Response(
                {
                    "ok": False,
                    "error": "کاربر یافت نشد"
                 },
                status=status.HTTP_404_NOT_FOUND
            )

        try:
            otp_code = OtpCode.objects.get(
                phone_number=phone_number,
                code=code
            )
        except OtpCode.DoesNotExist:
            return Response(
                {
                    "ok": False,
                    "error": "کد تایید اشتباه است"
                 },
                status=status.HTTP_400_BAD_REQUEST
            )

        if not otp_code.is_valid():
            otp_code.delete()

            return Response(
                {
                    "ok": False,
                    "error": "کد تایید منقضی شده است"
                 },
                status=status.HTTP_400_BAD_REQUEST
            )

        user = User.objects.get(phone_number=phone_number)

        otp_code.delete()

        refresh = RefreshToken.for_user(user)

        return Response(
            {
                "ok": True,
                "message": "ورود موفق",
                "refresh": str(refresh),
                "access": str(refresh.access_token)
            },
            status=status.HTTP_200_OK
        )
    




class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        data = {
            "ok": True,
            "phone_number": user.phone_number,
            "full_name": user.full_name,
            "is_shop": user.is_shop,
            "shop_name": user.shop_name,
            "shop_address": user.shop_address,
        }

        if not user.is_shop:
            customer_shops = CustomerShop.objects.filter(customer=user)
            debts = Debt.objects.filter(customer__in=customer_shops)

            total_debt = sum(d.amount for d in debts)
            total_paid = sum(d.paid_amount for d in debts)
            total_remaining = total_debt - total_paid

            data['debt_summary'] = {
                'total_debt': total_debt,
                'total_paid': total_paid,
                'total_remaining': total_remaining
            }

        return Response(data)
    

class MyShopsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.is_shop:
            return Response({
                "ok": False,
                "error": "شما یک فروشگاه هستید و نمی‌توانید فروشگاه‌ها را مشاهده کنید."
            }, status=status.HTTP_403_FORBIDDEN)
        
        customer_shops = CustomerShop.objects.filter(customer=request.user).select_related('shop')

        result = [
            {
                'shop_id': cs.shop.id,
                'shop_name': cs.shop.shop_name,
                'shop_address': cs.shop.shop_address,
            }
            for cs in customer_shops
        ]
        return Response({'ok': True, 'shops': result})




class MyShopHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, shop_id):
        if request.user.is_shop:
            return Response({'ok': False, 'error': 'این  برای مشتریان است'}, status=status.HTTP_403_FORBIDDEN)

        try:
            customer_shop = CustomerShop.objects.get(shop_id=shop_id, customer=request.user)
        except CustomerShop.DoesNotExist:
            return Response({'ok': False, 'error': 'شما در این فروشگاه ثبت نیستید'}, status=status.HTTP_404_NOT_FOUND)

        sales = Sale.objects.filter(shop_id=shop_id, customer=request.user).prefetch_related('items__product')
        debts = Debt.objects.filter(shop_id=shop_id, customer=customer_shop)

        total_purchase = sum(
            sum(item.price * item.quantity for item in sale.items.all())
            for sale in sales
        )
        total_debt = sum(d.amount for d in debts)
        total_paid = sum(d.paid_amount for d in debts)
        total_remaining = total_debt - total_paid

        return Response({
            'ok': True,
            'summary': {
                'total_purchase': total_purchase,
                'total_debt': total_debt,
                'total_paid': total_paid,
                'total_remaining': total_remaining
            },
            'sales': SaleSerializer(sales, many=True).data,
            'debts': DebtSerializer(debts, many=True).data
        })
    
class MeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.is_shop:
            return Response({'ok': False, 'error': 'این endpoint برای مشتریان است'}, status=status.HTTP_403_FORBIDDEN)

        customer_shops = CustomerShop.objects.filter(
            customer=request.user
        ).select_related('shop').annotate(
            total_amount=Sum('debts__amount'),
            total_paid=Sum('debts__payments__amount'),
            number_of_debts=Count('debts')
        )

        shops = [
            {
                'shop_id': cs.shop.id,
                'shop_name': cs.shop.shop_name,
                'shop_address': cs.shop.shop_address,
                'total_amount': (cs.total_amount or 0) - (cs.total_paid or 0),
                'number_of_debts': cs.number_of_debts or 0
            }
            for cs in customer_shops
        ]

        total_amount = sum(s['total_amount'] for s in shops)
        total_debts = sum(s['number_of_debts'] for s in shops)

        return Response({
            'ok': True,
            'total_amount': total_amount,
            'number_of_debts': total_debts,
            'shops': shops
        })